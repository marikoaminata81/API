package com.ami.Apigestion.Controller;

import com.ami.Apigestion.Entity.NombrePopulation;
import com.ami.Apigestion.Services.populationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping(path = "/api/population")
public class populationController {
    private com.ami.Apigestion.Services.populationService populationService;
    @Autowired
    public populationController(populationService populationService) {
        this.populationService = populationService;
    }
    //le mapping Conversion automatique de la classe de notre api en json
    @PostMapping(path ="/createPop")
    @ResponseStatus(HttpStatus.CREATED)
    public NombrePopulation add(@RequestBody NombrePopulation NombrePopulation){
        return this.populationService.savepopulation(NombrePopulation);
    }
    //recuperation de la liste
    @GetMapping(path = "/listPop")
    @ResponseStatus(HttpStatus.OK)
    public List<NombrePopulation> list(){
        return this.populationService.getAllPopulation();
    }
    @GetMapping(path = "/readPop/{IdPop}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<NombrePopulation> read(@PathVariable int IdPop){
        return this.populationService.getOnePopulation(IdPop);
    }
    @PutMapping(path="/updatePop/{IdPop}" )
    @ResponseStatus(HttpStatus.OK)
    public NombrePopulation update(@RequestBody NombrePopulation NombrePopulation,int IdPop){
        return this.populationService.updatePopulation(NombrePopulation, IdPop);
    }
    @DeleteMapping(path = "/removePop/{IdPop}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@PathVariable int IdPop){
        this.populationService.removeregion(IdPop);
    }
}
