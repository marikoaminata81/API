package com.ami.Apigestion.Controller;

import com.ami.Apigestion.Entity.NombrePopulation;
import com.ami.Apigestion.Entity.Pays;
import com.ami.Apigestion.Services.populationService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;
@RestController
@RequestMapping(path = "/api/pays")
public class paysController {
    private com.ami.Apigestion.Services.paysService paysService;
    @Autowired
    public paysController(com.ami.Apigestion.Services.paysService paysService) {
        this.paysService = paysService;
    }
    //le mapping Conversion automatique de la classe de notre api en json
    @PostMapping(path ="/createPays")
    @ResponseStatus(HttpStatus.CREATED)
    public Pays add(@RequestBody Pays Pays){
        return this.paysService.savepays(Pays);
    }
    //recuperation de la liste
    @GetMapping(path = "/listPays")
    @ResponseStatus(HttpStatus.OK)
    public List<Pays> list(){
        return this.paysService.getAllPays();
    }
    @GetMapping(path = "/readPays/{IdPays}")
    @ResponseStatus(HttpStatus.OK)
    public Optional<Pays> read(@PathVariable int IdPays){
        return this.paysService.getOnePopulation(IdPays);
    }
    @PutMapping(path="/updatePays/{IdPays}" )
    @ResponseStatus(HttpStatus.OK)
    public Pays update(@RequestBody Pays Pays,int IdPays){
        return this.paysService.updatePays(Pays, IdPays);
    }
    @DeleteMapping(path = "/removePays/{IdPays}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    public void remove(@PathVariable int IdPays){
        this.paysService.removepays(IdPays);
    }
}
