package com.ami.Apigestion.Entity;

import lombok.NoArgsConstructor;

import javax.persistence.*;

@Entity
@NoArgsConstructor
public class NombrePopulation {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private int id_pop;
    private int Annee;
    private int ChiffrePopulation;

    public NombrePopulation(int annee, int chiffrePopulation) {
        Annee = annee;
        ChiffrePopulation = chiffrePopulation;
    }

    public int getId_pop() {
        return id_pop;
    }

    public void setId_pop(int id_pop) {
        id_pop = id_pop;
    }

    public int getAnnee() {
        return Annee;
    }

    public void setAnnee(int annee) {
        Annee = annee;
    }

    public int getChiffrePopulation() {
        return ChiffrePopulation;
    }

    public void setChiffrePopulation(int chiffrePopulation) {
        ChiffrePopulation = chiffrePopulation;
    }
}
