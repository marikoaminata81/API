package com.ami.Apigestion.Controller;

import com.ami.Apigestion.Entity.region;
import com.ami.Apigestion.Services.regionService;
import lombok.AllArgsConstructor;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Optional;

@RestController
@RequestMapping("/api/region")
@AllArgsConstructor
public class regionController {

    private final regionService regionService;
    @PostMapping("/creationRegion")
    public region CreationRegion(@RequestBody region region){
        return regionService.creer(region);
    }
    @GetMapping
    public List<region> lireRegion(){
        return regionService.lire();
    }
    @PutMapping("/MAJRegion/{CodeRegion}")
    public region MAJRegion(int CodeRegion, region region){
        return regionService.modifier(CodeRegion,region);
    }
}

