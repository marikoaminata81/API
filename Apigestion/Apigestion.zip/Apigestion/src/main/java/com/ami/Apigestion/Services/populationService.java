package com.ami.Apigestion.Services;

import com.ami.Apigestion.Entity.NombrePopulation;
import com.ami.Apigestion.repository.populationDAO;
import com.ami.Apigestion.execption.regionNotFoundException;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class populationService {
    private com.ami.Apigestion.repository.populationDAO populationDAO;
    @Autowired
    public populationService(populationDAO populationDAO){
        this.populationDAO=populationDAO;
    }
    //enregistrer"C"
    public NombrePopulation savepopulation(NombrePopulation NombrePopulation){
        return this.populationDAO.save(NombrePopulation);
    }
    public List<NombrePopulation> getAllPopulation(){
        return this.populationDAO.findAll();
    }
    //montrer une region bien spécifique "R"
    public Optional<NombrePopulation> getOnePopulation(int IdPop){
        Optional<NombrePopulation>  NombrePopulation = this.populationDAO.findById(IdPop);
        if (!NombrePopulation.isPresent()){
            throw new regionNotFoundException(String.format("region with id %s not found!"+IdPop));
        }
        return this.populationDAO.findById(IdPop);
    }
    //mise à jour des données "U"
    public  NombrePopulation updatePopulation(NombrePopulation NombrePopulation, int IdPop){
        Optional<NombrePopulation> populationExist = this.populationDAO.findById(IdPop);
        if (!populationExist.isPresent()){
            throw new regionNotFoundException(String.format("region with id %s not found!"+IdPop));
        }
        return this.populationDAO.save(NombrePopulation);
    }
    //supprimer "D"
    public void removeregion(int IdPop){
        Optional<NombrePopulation>  NombrePopulation = this.populationDAO.findById(IdPop);
        if (!NombrePopulation.isPresent()){
            throw new regionNotFoundException(String.format("region with id %s not found!"+IdPop));
        }
        this.populationDAO.delete(NombrePopulation.get());
    }
}
