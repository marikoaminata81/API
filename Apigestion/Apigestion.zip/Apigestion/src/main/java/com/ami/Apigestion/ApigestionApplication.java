package com.ami.Apigestion;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ApigestionApplication {

	public static void main(String[] args) {
		SpringApplication.run(ApigestionApplication.class, args);
	}

}
