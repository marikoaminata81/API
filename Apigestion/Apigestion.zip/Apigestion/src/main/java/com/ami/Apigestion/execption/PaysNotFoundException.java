package com.ami.Apigestion.execption;

public class PaysNotFoundException extends RuntimeException{
    public PaysNotFoundException(String message){
        super(message);
    }
}
