package com.ami.Apigestion.Services;

import com.ami.Apigestion.Entity.NombrePopulation;
import com.ami.Apigestion.Entity.Pays;
import com.ami.Apigestion.execption.PaysNotFoundException;
import com.ami.Apigestion.execption.regionNotFoundException;
import com.ami.Apigestion.repository.paysDAO;
import com.ami.Apigestion.repository.populationDAO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class paysService {
    private com.ami.Apigestion.repository.paysDAO paysDAO;
    @Autowired
    public paysService(paysDAO paysDAO){
        this.paysDAO=paysDAO;
    }
    //enregistrer"C"
    public Pays savepays(Pays Pays){
        return this.paysDAO.save(Pays);
    }
    public List<Pays> getAllPays(){
        return this.paysDAO.findAll();
    }
    //montrer une region bien spécifique "R"
    public Optional<Pays> getOnePopulation(int IdPays){
        Optional<Pays>  Pays = this.paysDAO.findById(IdPays);
        if (!Pays.isPresent()){
            throw new regionNotFoundException(String.format("region with id %s not found!"+IdPays));
        }
        return this.paysDAO.findById(IdPays);
    }
    //mise à jour des données "U"
    public  Pays updatePays(Pays Pays, int IdPays){
        Optional<Pays> paysExist = this.paysDAO.findById(IdPays);
        if (!paysExist.isPresent()){
            throw new regionNotFoundException(String.format("region with id %s not found!"+IdPays));
        }
        return this.paysDAO.save(Pays);
    }
    //supprimer "D"
    public void removepays(int IdPays){
        Optional<Pays>  Pays = this.paysDAO.findById(IdPays);
        if (!Pays.isPresent()){
            throw new PaysNotFoundException(String.format("region with id %s not found!"+IdPays));
        }
        this.paysDAO.delete(Pays.get());
    }
}
