package com.ami.Apigestion;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ApigestionApplicationTests {

	@Test
	void contextLoads() {
	}

}
